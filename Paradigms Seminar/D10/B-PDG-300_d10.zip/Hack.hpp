#pragma once

class Hack
{
private:
    bool        _0;
    unsigned    _1;

public:
    virtual ~Hack() = default;

    void    hack(unsigned _) { _1 = _; }
};
